#!/usr/bin/env python3

import csv
import math
import os
import threading
import time

import rclpy
from rclpy.node import Node
from rclpy.action import ActionClient
from rclpy.duration import Duration

from nav2_msgs.action import NavigateToPose
from geometry_msgs.msg import Point
from tf2_ros import Buffer, TransformListener
from action_msgs.msg import GoalStatus
from visualization_msgs.msg import Marker, MarkerArray


WAYPOINTS_CSV_PATH = os.path.expanduser('~/nav_waypoints.csv')
WAYPOINTS_CSV_HEADER = ['label', 'x', 'y', 'yaw_deg']

POINT_MARKER_SIZE = 0.06
TEXT_LABEL_SCALE = 0.06
ARROW_LENGTH = 0.4
ARROW_WIDTH = 0.06


def yaw_deg_to_quaternion(yaw_deg):
    half_rad = math.radians(yaw_deg) / 2.0
    return math.sin(half_rad), math.cos(half_rad)


def quaternion_to_yaw_deg(x, y, z, w):
    siny_cosp = 2.0 * (w * z + x * y)
    cosy_cosp = 1.0 - 2.0 * (y * y + z * z)
    return math.degrees(math.atan2(siny_cosp, cosy_cosp))


def normalize_angle_deg(angle_deg):
    while angle_deg > 180.0:
        angle_deg -= 360.0
    while angle_deg <= -180.0:
        angle_deg += 360.0
    return angle_deg


class WaypointNav(Node):
    def __init__(self):
        super().__init__('nav_experiment_logger')

        self.declare_parameter('robot_base_frame', 'rear_axle_link')

        self.tf_buffer = Buffer()
        self.tf_listener = TransformListener(self.tf_buffer, self)
        self._action_client = ActionClient(self, NavigateToPose, 'navigate_to_pose')

        self.marker_pub = self.create_publisher(MarkerArray, 'nav_experiment_markers', 10)
        self.all_markers = []

        self.waypoints = {}
        self._waypoint_marker_id = {}
        self._next_waypoint_id = 1
        self.waypoint_count = 0

        self._load_waypoints()

    def get_current_pose(self):
        base_frame = self.get_parameter('robot_base_frame').value
        try:
            trans = self.tf_buffer.lookup_transform(
                'map', base_frame, rclpy.time.Time(),
                timeout=Duration(seconds=1.0))
            x = trans.transform.translation.x
            y = trans.transform.translation.y
            q = trans.transform.rotation
            yaw_deg = quaternion_to_yaw_deg(q.x, q.y, q.z, q.w)
            return x, y, yaw_deg
        except Exception as e:
            self.get_logger().warn(
                f'Could not read current pose (frame: map -> {base_frame}): {e}')
            return None, None, None

    def _make_point_marker(self, marker_id, x, y, r, g, b, ns):
        m = Marker()
        m.header.frame_id = 'map'
        m.header.stamp = self.get_clock().now().to_msg()
        m.ns = ns
        m.id = marker_id
        m.type = Marker.SPHERE
        m.action = Marker.ADD
        m.pose.position.x = x
        m.pose.position.y = y
        m.pose.position.z = 0.05
        m.pose.orientation.w = 1.0
        m.scale.x = POINT_MARKER_SIZE
        m.scale.y = POINT_MARKER_SIZE
        m.scale.z = POINT_MARKER_SIZE
        m.color.r, m.color.g, m.color.b, m.color.a = r, g, b, 0.9
        return m

    def _make_text_marker(self, marker_id, x, y, text, ns):
        t = Marker()
        t.header.frame_id = 'map'
        t.header.stamp = self.get_clock().now().to_msg()
        t.ns = ns
        t.id = marker_id
        t.type = Marker.TEXT_VIEW_FACING
        t.action = Marker.ADD
        t.pose.position.x = x
        t.pose.position.y = y
        t.pose.position.z = 0.35
        t.pose.orientation.w = 1.0
        t.scale.z = TEXT_LABEL_SCALE
        t.color.r, t.color.g, t.color.b, t.color.a = 1.0, 1.0, 1.0, 1.0
        t.text = text
        return t

    def _make_arrow_marker(self, marker_id, x, y, yaw_deg, r, g, b, ns,
                            length=ARROW_LENGTH, width=ARROW_WIDTH):
        m = Marker()
        m.header.frame_id = 'map'
        m.header.stamp = self.get_clock().now().to_msg()
        m.ns = ns
        m.id = marker_id
        m.type = Marker.ARROW
        m.action = Marker.ADD
        m.pose.position.x = x
        m.pose.position.y = y
        m.pose.position.z = 0.05
        qz, qw = yaw_deg_to_quaternion(yaw_deg)
        m.pose.orientation.z = qz
        m.pose.orientation.w = qw
        m.scale.x = length
        m.scale.y = width
        m.scale.z = width
        m.color.r, m.color.g, m.color.b, m.color.a = r, g, b, 0.9
        return m

    def _publish_waypoint_marker(self, label, x, y, yaw_deg):
        wp_id = self._waypoint_marker_id[label]

        self.all_markers = [
            m for m in self.all_markers
            if not (m.ns in ('waypoint', 'waypoint_label', 'waypoint_heading') and m.id == wp_id)
        ]

        purple = (0.7, 0.2, 1.0)
        self.all_markers.append(self._make_point_marker(wp_id, x, y, *purple, ns='waypoint'))
        text = f'{label} ({x:.2f},{y:.2f}) yaw={yaw_deg:.0f}°'
        self.all_markers.append(self._make_text_marker(wp_id, x, y, text, ns='waypoint_label'))
        self.all_markers.append(
            self._make_arrow_marker(wp_id, x, y, yaw_deg, *purple, ns='waypoint_heading'))

        arr = MarkerArray()
        arr.markers = self.all_markers
        self.marker_pub.publish(arr)

    def _load_waypoints(self):
        if not os.path.isfile(WAYPOINTS_CSV_PATH):
            return
        try:
            with open(WAYPOINTS_CSV_PATH, newline='', encoding='utf-8') as f:
                reader = csv.reader(f)
                next(reader, None)
                for row in reader:
                    if len(row) >= 4:
                        label, x, y, yaw = row[0], float(row[1]), float(row[2]), float(row[3])
                        self.waypoints[label] = (x, y, yaw)
                        self._waypoint_marker_id[label] = self._next_waypoint_id
                        self._next_waypoint_id += 1
            if self.waypoints:
                self.get_logger().info(
                    f'Loaded {len(self.waypoints)} existing waypoint(s) from {WAYPOINTS_CSV_PATH}')
                for label, (x, y, yaw) in self.waypoints.items():
                    self._publish_waypoint_marker(label, x, y, yaw)
        except Exception as e:
            self.get_logger().warn(f'Failed to load existing waypoints file: {e}')

    def _save_waypoints(self):
        with open(WAYPOINTS_CSV_PATH, 'w', newline='', encoding='utf-8') as f:
            writer = csv.writer(f)
            writer.writerow(WAYPOINTS_CSV_HEADER)
            for label, (x, y, yaw) in self.waypoints.items():
                writer.writerow([label, f'{x:.4f}', f'{y:.4f}', f'{yaw:.1f}'])

    def mark_waypoint(self, label=None):
        x, y, yaw = self.get_current_pose()
        if x is None:
            self.get_logger().error(
                'Could not read current pose right now, mark failed '
                '(check that tf map->robot_base_frame is available)')
            return False

        if not label:
            self.waypoint_count += 1
            label = f'wp{self.waypoint_count}'

        is_new = label not in self._waypoint_marker_id
        if is_new:
            self._waypoint_marker_id[label] = self._next_waypoint_id
            self._next_waypoint_id += 1

        self.waypoints[label] = (x, y, yaw)
        self._save_waypoints()
        self._publish_waypoint_marker(label, x, y, yaw)

        action = 'Marked new waypoint' if is_new else 'Re-marked waypoint (updated position)'
        self.get_logger().info(
            f'{action} "{label}" at ({x:.3f}, {y:.3f}) yaw={yaw:.1f}° '
            f'-> saved to {WAYPOINTS_CSV_PATH}')
        return True

    def list_waypoints(self):
        if not self.waypoints:
            print('No waypoints marked yet - drive to the desired spot and type "mark [label]"')
            return
        print(f'All marked waypoints ({len(self.waypoints)}):')
        for label, (x, y, yaw) in self.waypoints.items():
            print(f'  {label}: x={x:.3f}  y={y:.3f}  yaw={yaw:.1f}°')

    def go_to_waypoint(self, label, relative_yaw_deg=None):
        if label not in self.waypoints:
            self.get_logger().error(
                f'No waypoint named "{label}" (type "wp" to see available labels)')
            return
        goal_x, goal_y, stored_yaw_deg = self.waypoints[label]

        if relative_yaw_deg is not None:
            _cx, _cy, current_yaw_deg = self.get_current_pose()
            if current_yaw_deg is None:
                self.get_logger().error(
                    'Could not read current heading right now, cannot compute relative yaw')
                return
            goal_yaw_deg = normalize_angle_deg(current_yaw_deg + relative_yaw_deg)
            self.get_logger().info(
                f'Relative yaw requested: current heading ({current_yaw_deg:.1f}°) treated as '
                f'0°, +{relative_yaw_deg:.1f}° -> absolute goal yaw = {goal_yaw_deg:.1f}°')
        else:
            goal_yaw_deg = stored_yaw_deg

        self.get_logger().info(
            f'=== Driving to "{label}" ({goal_x:.2f}, {goal_y:.2f}) '
            f'heading={goal_yaw_deg:.1f}° ===')

        if not self._action_client.wait_for_server(timeout_sec=5.0):
            self.get_logger().error('navigate_to_pose action server not found (is nav2 up?)')
            return

        goal_msg = NavigateToPose.Goal()
        goal_msg.pose.header.frame_id = 'map'
        goal_msg.pose.header.stamp = self.get_clock().now().to_msg()
        goal_msg.pose.pose.position.x = goal_x
        goal_msg.pose.pose.position.y = goal_y
        qz, qw = yaw_deg_to_quaternion(goal_yaw_deg)
        goal_msg.pose.pose.orientation.z = qz
        goal_msg.pose.pose.orientation.w = qw

        send_goal_future = self._action_client.send_goal_async(goal_msg)
        while not send_goal_future.done():
            time.sleep(0.05)
        goal_handle = send_goal_future.result()

        if not goal_handle.accepted:
            self.get_logger().error('Goal was rejected by nav2')
            return

        get_result_future = goal_handle.get_result_async()
        while not get_result_future.done():
            time.sleep(0.05)
        result = get_result_future.result()
        status = result.status

        if status == GoalStatus.STATUS_SUCCEEDED:
            self.get_logger().info(f'=== Arrived at "{label}" ===')
        elif status == GoalStatus.STATUS_CANCELED:
            self.get_logger().warn(f'=== Canceled while driving to "{label}" ===')
        else:
            self.get_logger().warn(f'=== Failed to reach "{label}" (status={status}) ===')

def main():
    rclpy.init()
    node = WaypointNav()

    # spin the node in a background thread so the TF buffer keeps
    # receiving /tf messages while we block on input() in the main thread
    spin_thread = threading.Thread(target=rclpy.spin, args=(node,), daemon=True)
    spin_thread.start()

    node.get_logger().info(
        'Available commands:\n'
        '  mark [label]        - mark the current position as a waypoint\n'
        '                         (no label -> auto-named wp1, wp2, wp3, ...)\n'
        '  wp                  - list all marked waypoints\n'
        '  go <label>          - drive to that waypoint using its stored heading\n'
        '  go <label> <deg>    - drive to that waypoint, ending at <deg> degrees\n'
        '                        relative to the robot\'s CURRENT heading right now\n'
        '                        e.g. "go wp1 90"\n'
        '  q                   - quit'
    )
    try:
        while rclpy.ok():
            line = input('mark [label] | wp | go <label> [deg] | q > ').strip()
            if not line:
                continue
            if line.lower() == 'q':
                break

            parts = line.split()
            cmd = parts[0].lower()

            if cmd == 'mark':
                label = parts[1] if len(parts) >= 2 else None
                node.mark_waypoint(label)
            elif cmd in ('wp', 'list', 'waypoints'):
                node.list_waypoints()
            elif cmd == 'go':
                if len(parts) < 2:
                    print('Usage: go <label> [relative_deg]  e.g. go wp1  or  go wp1 90')
                else:
                    label = parts[1]
                    relative_yaw_deg = None
                    if len(parts) >= 3:
                        try:
                            relative_yaw_deg = float(parts[2])
                        except ValueError:
                            print('relative_deg must be a number, e.g.: go wp1 90')
                            continue
                    node.go_to_waypoint(label, relative_yaw_deg)
            else:
                print('Unknown command - type "mark [label]" / "wp" / "go <label> [deg]" / "q"')
    except (KeyboardInterrupt, EOFError):
        pass

    rclpy.shutdown()
    node.destroy_node()

if __name__ == '__main__':
    main()