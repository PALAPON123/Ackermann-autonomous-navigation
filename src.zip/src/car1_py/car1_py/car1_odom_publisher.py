#!/usr/bin/env python3
"""
car1_odom_publisher.py
รวม imu_processor (bias calibration) + odom estimator (encoder/IMU vyaw fusion) ไว้โหนดเดียว
"""

import math

import rclpy
from rclpy.node import Node
from collections import deque
from rclpy.qos import QoSProfile, ReliabilityPolicy, HistoryPolicy

from car1_msgs.msg import OdomLite
from nav_msgs.msg import Odometry
from geometry_msgs.msg import TransformStamped
from tf2_ros import TransformBroadcaster
from std_msgs.msg import Float32
from sensor_msgs.msg import Imu
from sensor_msgs.msg import JointState  # <<< แก้: เพิ่ม import


def yaw_to_quaternion(yaw: float):
    return (0.0, 0.0, math.sin(yaw * 0.5), math.cos(yaw * 0.5))


class Car1OdomPublisher(Node):
    def __init__(self):
        super().__init__('car1_odom_publisher')

        # ---------- odom / fusion params ----------
        self.declare_parameter('odom_frame', 'odom')
        self.declare_parameter('base_frame', 'base_link')
        self.declare_parameter('publish_tf', False)
        self.declare_parameter('pos_cov_xy', 0.02)
        self.declare_parameter('pos_cov_theta', 0.03)
        self.declare_parameter('vx_variance', 0.0025)
        self.declare_parameter('vyaw_variance', 0.02)
        self.declare_parameter('steer_stale_timeout', 0.3)
        self.declare_parameter('imu_stale_timeout', 0.3)

        # ---------- steering pot calibration params ----------
        self.declare_parameter('pot_v_left', 0.77)
        self.declare_parameter('pot_v_center', 1.72)
        self.declare_parameter('pot_v_right', 2.56)
        self.declare_parameter('max_steer_left', 0.5847)
        self.declare_parameter('max_steer_right', 0.5719)
        self.declare_parameter('pot_filter_alpha', 0.3)

        # ---------- IMU bias calibration params ----------
        self.declare_parameter('idle_accel_band', 0.3)
        self.declare_parameter('idle_window_sec', 2.0)
        self.declare_parameter('bias_blend', 1.0)

        # ---- load ----
        self.odom_frame = self.get_parameter('odom_frame').value
        self.base_frame = self.get_parameter('base_frame').value
        self.publish_tf_flag = self.get_parameter('publish_tf').value
        self.pos_cov_xy = self.get_parameter('pos_cov_xy').value
        self.pos_cov_theta = self.get_parameter('pos_cov_theta').value
        self.vx_variance = self.get_parameter('vx_variance').value
        self.vyaw_variance = self.get_parameter('vyaw_variance').value
        self.steer_stale_timeout = self.get_parameter('steer_stale_timeout').value
        self.imu_stale_timeout = self.get_parameter('imu_stale_timeout').value

        self.pot_v_left = self.get_parameter('pot_v_left').value
        self.pot_v_center = self.get_parameter('pot_v_center').value
        self.pot_v_right = self.get_parameter('pot_v_right').value
        self.max_steer_left = self.get_parameter('max_steer_left').value
        self.max_steer_right = self.get_parameter('max_steer_right').value
        self.pot_filter_alpha = self.get_parameter('pot_filter_alpha').value

        self.idle_accel_band = self.get_parameter('idle_accel_band').value
        self.idle_window_sec = self.get_parameter('idle_window_sec').value
        self.bias_blend = self.get_parameter('bias_blend').value
        self.declare_parameter('idle_vx_threshold', 0.02)
        self.idle_vx_threshold = self.get_parameter('idle_vx_threshold').value
        self.last_vx = 0.0
        self.declare_parameter('rear_axle_offset_x', 0.15)
        self.declare_parameter('vy_variance', 0.01)
        self.rear_axle_offset_x = self.get_parameter('rear_axle_offset_x').value
        self.vy_variance = self.get_parameter('vy_variance').value

        # ---- state: steering ----
        self.steer_rad = 0.0
        self.steer_rad_filtered = 0.0
        self.last_steer_time = None

        # ---- state: IMU (raw -> corrected) ----
        self.imu_gz = 0.0
        self.last_imu_time = None
        self.gz_bias = 0.0
        self.ax_bias = 0.0
        self.ay_bias = 0.0
        self._reset_imu_window()

        # ---- state: odom integration ----
        self.x = 0.0
        self.y = 0.0
        self.theta = 0.0
        self.last_stamp = None
        self.accum_pos_var = 0.0
        self.accum_yaw_var = 0.0

        qos = QoSProfile(
            reliability=ReliabilityPolicy.BEST_EFFORT,
            history=HistoryPolicy.KEEP_LAST,
            depth=10,
        )

        self.sub = self.create_subscription(
            OdomLite, '/odom_lite', self.odom_lite_cb, qos)
        self.steer_sub = self.create_subscription(
            Float32, '/steering_pot_voltage', self.steer_cb, qos)
        self.imu_sub = self.create_subscription(
            Imu, '/imu/data_raw', self.imu_cb, qos)

        # <<< แก้: subscribe joint_states ดิบจาก ESP32 แล้ว restamp เป็นเวลา PC
        # ก่อนส่งต่อเป็น /joint_states ตัวจริงที่ robot_state_publisher ใช้
        # เหตุผล: stamp เดิมจาก ESP32 ใช้ epoch_offset_ms (MCU clock, resync ทุก 2s)
        # ไม่ตรงกับ PC clock ที่ /odom ใช้ ทำให้ TF ของ wheel_link กับ base_link
        # ไม่ sync กัน เห็นเป็นล้อ "หลุด" จากตัวถังใน RViz ตลอดเวลา
        self.joint_sub = self.create_subscription(
            JointState, '/joint_states_raw', self.joint_states_cb, qos)
        self.joint_pub = self.create_publisher(JointState, '/joint_states', 10)

        self.odom_pub = self.create_publisher(Odometry, '/odom', 10)
        self.imu_pub = self.create_publisher(Imu, '/imu/data', qos)
        self.tf_broadcaster = TransformBroadcaster(self)

        self.get_logger().info(
            'car1_odom_publisher started (IMU bias-cal + steer-cal + vyaw fusion + joint restamp, all on PC)')

    # ---------------------------------------------------------------
    # Joint states: restamp MCU clock -> PC clock แล้วส่งต่อ
    # ---------------------------------------------------------------
    def joint_states_cb(self, msg: JointState):  # <<< แก้: เมธอดใหม่
        msg.header.stamp = self.get_clock().now().to_msg()
        self.joint_pub.publish(msg)

    # ---------------------------------------------------------------
    # IMU: raw -> bias-corrected, publish /imu/data, เก็บ self.imu_gz ไว้ fuse
    # ---------------------------------------------------------------
    def _reset_imu_window(self):
        self.win_start = None
        self.win_ax_min = 1e9; self.win_ax_max = -1e9
        self.win_ay_min = 1e9; self.win_ay_max = -1e9
        self.win_gz_sum = 0.0; self.win_ax_sum = 0.0; self.win_ay_sum = 0.0
        self.win_count = 0

    def imu_cb(self, msg: Imu):
        stamp = rclpy.time.Time.from_msg(msg.header.stamp)
        ax_raw = msg.linear_acceleration.x
        ay_raw = msg.linear_acceleration.y
        gz_raw = msg.angular_velocity.z

        if self.win_start is None:
            self.win_start = stamp
            self.win_ax_min = self.win_ax_max = ax_raw
            self.win_ay_min = self.win_ay_max = ay_raw
            self.win_gz_sum = gz_raw; self.win_ax_sum = ax_raw; self.win_ay_sum = ay_raw
            self.win_count = 1
        else:
            self.win_ax_min = min(self.win_ax_min, ax_raw)
            self.win_ax_max = max(self.win_ax_max, ax_raw)
            self.win_ay_min = min(self.win_ay_min, ay_raw)
            self.win_ay_max = max(self.win_ay_max, ay_raw)

            accel_stable = ((self.win_ax_max - self.win_ax_min) < self.idle_accel_band and
                 (self.win_ay_max - self.win_ay_min) < self.idle_accel_band and
                 abs(self.last_vx) < self.idle_vx_threshold)

            if not accel_stable:
                self._reset_imu_window()
                self.win_start = stamp
                self.win_ax_min = self.win_ax_max = ax_raw
                self.win_ay_min = self.win_ay_max = ay_raw
                self.win_gz_sum = gz_raw; self.win_ax_sum = ax_raw; self.win_ay_sum = ay_raw
                self.win_count = 1
            else:
                self.win_gz_sum += gz_raw
                self.win_ax_sum += ax_raw
                self.win_ay_sum += ay_raw
                self.win_count += 1

                elapsed = (stamp - self.win_start).nanoseconds * 1e-9
                if elapsed >= self.idle_window_sec:
                    a = self.bias_blend
                    self.gz_bias = a * (self.win_gz_sum / self.win_count) + (1 - a) * self.gz_bias
                    self.ax_bias = a * (self.win_ax_sum / self.win_count) + (1 - a) * self.ax_bias
                    self.ay_bias = a * (self.win_ay_sum / self.win_count) + (1 - a) * self.ay_bias
                    self.get_logger().info(
                        f'[CAL] gz_bias={self.gz_bias:.5f} ax_bias={self.ax_bias:.4f} ay_bias={self.ay_bias:.4f}')
                    self._reset_imu_window()

        gz_corrected = gz_raw - self.gz_bias
        self.imu_gz = gz_corrected
        self.last_imu_time = self.get_clock().now()

        out = Imu()
        out.header = msg.header
        out.header.stamp = self.get_clock().now().to_msg()  # <<< แก้: ใช้เวลา PC แทน stamp จาก ESP32
        out.linear_acceleration.x = ax_raw - self.ax_bias
        out.linear_acceleration.y = ay_raw - self.ay_bias
        out.linear_acceleration.z = msg.linear_acceleration.z
        out.angular_velocity.x = msg.angular_velocity.x
        out.angular_velocity.y = msg.angular_velocity.y
        out.angular_velocity.z = gz_corrected
        out.orientation_covariance = msg.orientation_covariance
        out.angular_velocity_covariance = msg.angular_velocity_covariance
        out.linear_acceleration_covariance = msg.linear_acceleration_covariance
        self.imu_pub.publish(out)

    # ---------------------------------------------------------------
    # Steering: raw voltage -> radian (calibration) -> EMA filter
    # ---------------------------------------------------------------
    def steer_cb(self, msg: Float32):
        v = msg.data
        if v <= self.pot_v_center:
            rad = self.max_steer_left * (self.pot_v_center - v) / (self.pot_v_center - self.pot_v_left)
        else:
            rad = -self.max_steer_right * (v - self.pot_v_center) / (self.pot_v_right - self.pot_v_center)
        rad = max(-self.max_steer_right, min(self.max_steer_left, rad))

        self.steer_rad_filtered += self.pot_filter_alpha * (rad - self.steer_rad_filtered)
        self.steer_rad = self.steer_rad_filtered
        self.last_steer_time = self.get_clock().now()

    # ---------------------------------------------------------------
    # Odom: encoder delta -> vx, vyaw_enc, fuse กับ imu_gz, integrate pose
    # ---------------------------------------------------------------
    def odom_lite_cb(self, msg: OdomLite):
        stamp = self.get_clock().now()
        self.last_vx = msg.vx

        if self.last_stamp is None:
            self.last_stamp = stamp
            return

        dt = (stamp - self.last_stamp).nanoseconds * 1e-9
        self.last_stamp = stamp

        if dt <= 0.0 or dt > 0.5:
            self.get_logger().warn(f'skip integration, bad dt={dt:.4f}s')
            return

        vx = msg.vx

        imu_fresh = (self.last_imu_time is not None and
                     (self.get_clock().now() - self.last_imu_time).nanoseconds * 1e-9 < self.imu_stale_timeout)

        if imu_fresh:
            vyaw = self.imu_gz
        else:
            vyaw = 0.0
            self.get_logger().warn('imu stale, vyaw forced to 0', throttle_duration_sec=1.0)

        vy_body = vyaw * self.rear_axle_offset_x

        theta_mid = self.theta + vyaw * dt * 0.5
        vx_world = vx * math.cos(theta_mid) - vy_body * math.sin(theta_mid)
        vy_world = vx * math.sin(theta_mid) + vy_body * math.cos(theta_mid)
        self.x += vx_world * dt
        self.y += vy_world * dt
        self.theta += vyaw * dt
        self.theta = math.atan2(math.sin(self.theta), math.cos(self.theta))

        self.publish_odom(stamp, vx, vyaw, dt, vy_body)

    def publish_odom(self, stamp, vx: float, vyaw: float, dt: float, vy: float = 0.0):
        qx, qy, qz, qw = yaw_to_quaternion(self.theta)

        odom = Odometry()
        odom.header.stamp = stamp.to_msg()
        odom.header.frame_id = self.odom_frame
        odom.child_frame_id = self.base_frame

        odom.pose.pose.position.x = self.x
        odom.pose.pose.position.y = self.y
        odom.pose.pose.position.z = 0.0
        odom.pose.pose.orientation.x = qx
        odom.pose.pose.orientation.y = qy
        odom.pose.pose.orientation.z = qz
        odom.pose.pose.orientation.w = qw

        odom.twist.twist.linear.x = vx
        odom.twist.twist.linear.y = vy
        odom.twist.twist.angular.z = vyaw

        self.accum_pos_var += self.pos_cov_xy * max(dt, 0.001)
        self.accum_yaw_var += self.pos_cov_theta * max(dt, 0.001)
        pos_var = self.accum_pos_var
        yaw_var = self.accum_yaw_var
        pose_cov = [0.0] * 36
        pose_cov[0] = pos_var
        pose_cov[7] = pos_var
        pose_cov[14] = 1e6
        pose_cov[21] = 1e6
        pose_cov[28] = 1e6
        pose_cov[35] = yaw_var
        odom.pose.covariance = pose_cov

        twist_cov = [0.0] * 36
        twist_cov[0] = self.vx_variance
        twist_cov[7] = self.vy_variance
        twist_cov[14] = 1e6
        twist_cov[21] = 1e6
        twist_cov[28] = 1e6
        twist_cov[35] = self.vyaw_variance
        odom.twist.covariance = twist_cov

        self.odom_pub.publish(odom)

        if self.publish_tf_flag:
            t = TransformStamped()
            t.header.stamp = stamp.to_msg()
            t.header.frame_id = self.odom_frame
            t.child_frame_id = self.base_frame
            t.transform.translation.x = self.x
            t.transform.translation.y = self.y
            t.transform.translation.z = 0.0
            t.transform.rotation.x = qx
            t.transform.rotation.y = qy
            t.transform.rotation.z = qz
            t.transform.rotation.w = qw
            self.tf_broadcaster.sendTransform(t)


def main(args=None):
    rclpy.init(args=args)
    node = Car1OdomPublisher()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()