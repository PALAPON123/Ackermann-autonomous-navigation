#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Joy
from action_msgs.srv import CancelGoal
import time


class JoyOverrideWatchdog(Node):
    def __init__(self):
        super().__init__('joy_override_watchdog')

        self.declare_parameter('deadzone', 0.15)
        self.declare_parameter('override_button_index', -1)
        self.deadzone = self.get_parameter('deadzone').value
        self.btn_idx = self.get_parameter('override_button_index').value
        self.declare_parameter('watched_axes', [0, 1])
        self.watched_axes = self.get_parameter('watched_axes').value

        # ── เพิ่ม debounce ด้วยเวลาจริง กันการสลับถี่จาก joystick noise ──
        self.declare_parameter('cooldown_sec', 1.0)
        self.cooldown_sec = self.get_parameter('cooldown_sec').value
        self.last_trigger_time = 0.0

        self.cancel_clients = {
            'navigate_to_pose': self.create_client(
                CancelGoal, '/navigate_to_pose/_action/cancel_goal'),
            'navigate_through_poses': self.create_client(
                CancelGoal, '/navigate_through_poses/_action/cancel_goal'),
        }

        self.sub = self.create_subscription(
            Joy, '/joy', self.joy_cb, 10)

        self.override_active = False

    def joy_cb(self, msg: Joy):
        moved = any(
            abs(msg.axes[i]) > self.deadzone
            for i in self.watched_axes
            if i < len(msg.axes)
        )
        btn_pressed = (self.btn_idx >= 0
                       and len(msg.buttons) > self.btn_idx
                       and msg.buttons[self.btn_idx] == 1)

        triggered = moved or btn_pressed
        now = time.time()

        if triggered and not self.override_active:
            # ── cooldown กันยิงซ้ำถี่เกินไปจาก noise ──
            if now - self.last_trigger_time < self.cooldown_sec:
                return
            self.override_active = True
            self.last_trigger_time = now
            self.cancel_all_nav_goals()
        elif not triggered:
            self.override_active = False

    def cancel_all_nav_goals(self):
        self.get_logger().warn('Joystick override -> cancelling nav2 goals')
        for name, client in self.cancel_clients.items():
            if not client.service_is_ready():
                self.get_logger().debug(f'{name} cancel service not ready, skipping')
                continue
            # ── ส่ง cancel request จริง (เดิมไม่มีบรรทัดนี้เลย) ──
            request = CancelGoal.Request()
            future = client.call_async(request)
            future.add_done_callback(
                lambda f, n=name: self.get_logger().info(f'Cancelled {n}')
            )


def main():
    rclpy.init()
    node = JoyOverrideWatchdog()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()