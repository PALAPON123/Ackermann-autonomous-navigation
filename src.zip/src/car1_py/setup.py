from setuptools import find_packages, setup

package_name = 'car1_py'

setup(
    name=package_name,
    version='0.0.0',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='pon',
    maintainer_email='pon@todo.todo',
    description='TODO: Package description',
    license='TODO: License declaration',
    extras_require={
        'test': [
            'pytest',
        ],
    },
    entry_points={
    'console_scripts': [
        'car1_odom_publisher = car1_py.car1_odom_publisher:main',
        'nav_experiment_logger = car1_py.nav_experiment_logger:main',
        'joy_override_watchdog = car1_py.joy_override_watchdog:main',
        ],
    },
)
