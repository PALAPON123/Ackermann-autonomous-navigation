#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from nav_msgs.msg import Odometry
from geometry_msgs.msg import TransformStamped
from tf2_ros import TransformBroadcaster
from rclpy.qos import QoSProfile, ReliabilityPolicy, HistoryPolicy, DurabilityPolicy

class OdomTFBroadcaster(Node):
    def __init__(self):
        super().__init__('odom_tf_broadcaster')
        self.br = TransformBroadcaster(self)
        self.last_tf = None
        qos = QoSProfile(
            reliability=ReliabilityPolicy.BEST_EFFORT,
            durability=DurabilityPolicy.VOLATILE,
            history=HistoryPolicy.KEEP_LAST,
            depth=10
        )
        self.create_subscription(Odometry, '/odom', self.cb, qos)
        self.create_timer(0.05, self.timer_cb)
        self.get_logger().info('odom_tf_broadcaster ready')

    def cb(self, msg):
        t = TransformStamped()
        t.header.frame_id = 'odom'
        t.child_frame_id  = 'base_link'
        t.transform.translation.x = msg.pose.pose.position.x
        t.transform.translation.y = msg.pose.pose.position.y
        t.transform.translation.z = 0.0
        t.transform.rotation = msg.pose.pose.orientation
        self.last_tf = t
        t.header.stamp = self.get_clock().now().to_msg()
        self.br.sendTransform(t)

    def timer_cb(self):
        if self.last_tf is not None:
            self.last_tf.header.stamp = self.get_clock().now().to_msg()
            self.br.sendTransform(self.last_tf)

def main():
    rclpy.init()
    rclpy.spin(OdomTFBroadcaster())

if __name__ == '__main__':
    main()
