#!/usr/bin/env python3
import socket, struct, math
import rclpy
from rclpy.node import Node
from sensor_msgs.msg import LaserScan

LIDAR_MAX_PTS = 360
UDP_PORT      = 9999

class LidarUdpNode(Node):
    def __init__(self):
        super().__init__('lidar_udp_node')
        self.pub    = self.create_publisher(LaserScan, '/scan', 10)
        self.ranges = [0.0] * LIDAR_MAX_PTS
        self.sock   = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.sock.bind(('0.0.0.0', UDP_PORT))
        self.sock.setblocking(False)
        self.create_timer(0.05, self.update)
        self.get_logger().info(f'lidar_udp_node listening UDP:{UDP_PORT}')

    def update(self):
        try:
            while True:
                data, _ = self.sock.recvfrom(512)
                self.parse(data)
        except BlockingIOError:
            pass
        msg = LaserScan()
        msg.header.stamp    = self.get_clock().now().to_msg()
        msg.header.frame_id = 'laser_frame'
        msg.angle_min       = -math.pi
        msg.angle_max       =  math.pi
        msg.angle_increment = 2.0 * math.pi / LIDAR_MAX_PTS
        msg.time_increment  = (1.0/10.0) / LIDAR_MAX_PTS
        msg.scan_time       = 1.0 / 10.0
        msg.range_min       = 0.1
        msg.range_max       = 12.0
        msg.ranges          = list(self.ranges)
        self.pub.publish(msg)

    def parse(self, buf):
        if len(buf) < 10: return
        ct  = buf[2]
        qty = buf[3]
        if ct & 0x01: return
        if qty == 0:  return
        if len(buf) < 10 + qty * 2: return
        sa = (struct.unpack_from('<H', buf, 4)[0] >> 1) / 64.0
        ea = (struct.unpack_from('<H', buf, 6)[0] >> 1) / 64.0
        if ea < sa: ea += 360.0
        step = (ea - sa) / (qty - 1) if qty > 1 else 0.0
        for i in range(qty):
            bi = 10 + i * 2
            if bi + 1 >= len(buf): break
            d = (struct.unpack_from('<H', buf, bi)[0] >> 2) / 1000.0
            if d < 0.1 or d > 12.0: d = 0.0
            angle = (sa + step * i) % 360.0
            self.ranges[int(angle) % LIDAR_MAX_PTS] = d

def main():
    rclpy.init()
    rclpy.spin(LidarUdpNode())

if __name__ == '__main__':
    main()