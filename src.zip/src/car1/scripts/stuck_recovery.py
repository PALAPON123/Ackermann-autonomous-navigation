#!/usr/bin/env python3
import math
import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
from nav_msgs.msg import Odometry
from rclpy.qos import QoSProfile, ReliabilityPolicy, DurabilityPolicy, HistoryPolicy

STUCK_CMD_THRESHOLD  = 0.05
STUCK_MOVE_THRESHOLD = 0.001
STUCK_WINDOW_SEC     = 0.8
STUCK_CONFIRM_SEC    = 0.5
REVERSE_VEL          = -0.32
REVERSE_SEC          = 1.2
STEER_OMEGA          = 0.45
PAUSE_SEC            = 0.4
CMD_VEL_TOPIC        = '/recovery_cmd_vel'
NAV_CMD_VEL_TOPIC    = '/nav_cmd_vel'
ODOM_TOPIC           = '/odometry/filtered'

class StuckRecovery(Node):
    def __init__(self):
        super().__init__('stuck_recovery')
        self._pos_history = []
        self._cmd_active_since = None
        self._stuck_since = None
        self._recovery_end = None
        self._pause_end = None
        self._steer_sign = 1.0
        self._in_recovery = False
        self._last_nav_cmd_vx = 0.0
        self._cmd_pub = self.create_publisher(Twist, CMD_VEL_TOPIC, 10)
        odom_qos = QoSProfile(
            reliability=ReliabilityPolicy.BEST_EFFORT,
            durability=DurabilityPolicy.VOLATILE,
            history=HistoryPolicy.KEEP_LAST,
            depth=10
        )
        self.create_subscription(Odometry, ODOM_TOPIC, self._odom_cb, odom_qos)
        self.create_subscription(Twist, NAV_CMD_VEL_TOPIC, self._nav_cmd_cb, 10)
        self.create_timer(0.1, self._tick)
        self.get_logger().info('[StuckRecovery] node started')

    def _nav_cmd_cb(self, msg):
        self._last_nav_cmd_vx = abs(msg.linear.x) + abs(msg.angular.z)

    def _odom_cb(self, msg):
        now = self.get_clock().now().nanoseconds * 1e-9
        x = msg.pose.pose.position.x
        y = msg.pose.pose.position.y
        self._pos_history.append((now, x, y))
        cutoff = now - STUCK_WINDOW_SEC
        self._pos_history = [(t, px, py) for t, px, py in self._pos_history if t >= cutoff]

    def _tick(self):
        now = self.get_clock().now().nanoseconds * 1e-9

        if self._in_recovery:
            if self._recovery_end is not None and now < self._recovery_end:
                msg = Twist()
                msg.linear.x  = REVERSE_VEL
                msg.angular.z = 0.0
                self._cmd_pub.publish(msg)
                return
            if self._pause_end is None:
                self._cmd_pub.publish(Twist())
                self._pause_end = now + PAUSE_SEC
                self.get_logger().info('[StuckRecovery] reverse done, pausing')
                return
            if now < self._pause_end:
                return
            self._in_recovery  = False
            self._recovery_end = None
            self._pause_end    = None
            self._cmd_active_since = None
            self._stuck_since      = None
            self._steer_sign      *= -1.0
            self.get_logger().info('[StuckRecovery] resuming nav')
            return

        nav_commanding = self._last_nav_cmd_vx > STUCK_CMD_THRESHOLD
        if not nav_commanding:
            self._cmd_active_since = None
            self._stuck_since      = None
            return
        if self._cmd_active_since is None:
            self._cmd_active_since = now
        if now - self._cmd_active_since < STUCK_WINDOW_SEC:
            return
        if len(self._pos_history) < 2:
            return
        oldest = self._pos_history[0]
        newest = self._pos_history[-1]
        dist_moved = math.hypot(newest[1] - oldest[1], newest[2] - oldest[2])
        if dist_moved >= STUCK_MOVE_THRESHOLD:
            self._stuck_since = None
            return
        if self._stuck_since is None:
            self._stuck_since = now
            self.get_logger().warn(f'[StuckRecovery] possible stuck (moved {dist_moved*100:.1f} cm)')
            return
        if now - self._stuck_since < STUCK_CONFIRM_SEC:
            return
        self._in_recovery  = True
        self._recovery_end = now + REVERSE_SEC
        self._pause_end    = None
        self.get_logger().warn(f'[StuckRecovery] STUCK! reversing for {REVERSE_SEC}s')

def main(args=None):
    rclpy.init(args=args)
    node = StuckRecovery()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
