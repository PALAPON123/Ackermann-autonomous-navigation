"""
teleop_real.launch.py v20

"""
import os
from launch import LaunchDescription
from launch_ros.actions import Node
from launch.actions import TimerAction, ExecuteProcess
from ament_index_python.packages import get_package_share_directory

def generate_launch_description():
    pkg = get_package_share_directory('car1')

    urdf_path = os.path.join(pkg, 'urdf', 'car1.urdf')
    if not os.path.exists(urdf_path):
        urdf_path = os.path.join(pkg, 'urdf', 'car1.urdf.xacro')
    with open(urdf_path, 'r') as f:
        robot_description = f.read()

    nav2_params  = os.path.join(pkg, 'config', 'nav2_params.yaml')
    slam_params_file = os.path.join(pkg, 'config', 'slam_params.yaml')
    rviz_config  = os.path.join(pkg, 'rviz', 'teleop_real.rviz')
    rviz_args    = ['-d', rviz_config] if os.path.exists(rviz_config) else []

    nav2_nodes = [
        'planner_server',
        'controller_server',
        'smoother_server',
        'behavior_server',
        'bt_navigator',
        'waypoint_follower',
    ]

    return LaunchDescription([

        Node(
            package='robot_state_publisher',
            executable='robot_state_publisher',
            parameters=[{'robot_description': robot_description,
                        'use_sim_time': False,
                        'publish_frequency': 50.0,
                        'qos_overrides': {
                            '/joint_states': {
                                'subscription': {
                                    'depth': 20,
                                    'history': 'keep_last',
                                    'reliability': 'best_effort',
                                }
                            }
                        }}],
            output='screen',
        ),
     
        Node(
            package='joy',
            executable='joy_node',
            parameters=[{'device_id': 0, 'deadzone': 0.05,
                         'autorepeat_rate': 50.0}],
            output='screen',
        ),

        Node(
            package='car1',
            executable='joy_to_cmd',
            parameters=[{'max_speed': 0.35, 'max_steer': 0.568,
                        'deadzone': 0.05}],
            remappings=[('cmd_vel', '/joy_cmd_vel')],  
            output='screen',
        ),
        Node(
            package='car1_py',
            executable='joy_override_watchdog',
            name='joy_override_watchdog',
            parameters=[{
                'deadzone': 0.15,
                'watched_axes': [0, 1],
                'override_button_index': -1,
            }],
            output='screen',
        ),
        Node(
            package='tf2_ros',
            executable='static_transform_publisher',
            name='lidar_tf',
            arguments=['--x','0','--y','0','--z','0.13',
                       '--roll','0','--pitch','0','--yaw','0',
                       '--frame-id','base_link',
                       '--child-frame-id','laser_frame'],
        ),

        Node(
            package='tf2_ros',
            executable='static_transform_publisher',
            name='imu_tf',
            arguments=['--x','0','--y','0','--z','0.05',
                       '--roll','0','--pitch','0','--yaw','0',
                       '--frame-id','base_link',
                       '--child-frame-id','imu_link'],
        ),
        
        Node(
            package='laser_filters',
            executable='scan_to_scan_filter_chain',
            name='scan_filter',
            parameters=[os.path.join(pkg, 'config', 'scan_filter.yaml')],
            remappings=[
                ('scan', '/scan'),
                ('scan_filtered', '/scan_filtered'),
            ],
            output='screen',
        ),
    
        Node(
            package='robot_localization',
            executable='ekf_node',
            name='ekf_filter_node',
            output='screen',
            parameters=[
                os.path.join(pkg, 'config', 'ekf.yaml'),
                {'use_sim_time': False}
            ],
        ),
 
        Node(
            package='topic_tools',
            executable='relay',
            name='cmd_vel_qos_relay',
            parameters=[{
                'input_topic':  '/cmd_vel',
                'output_topic': '/cmd_vel_gated',
                'reliability':  'best_effort',
                'lazy':         False,  
            }],
            output='screen',
        ),
        
        Node(
            package='car1_py',
            executable='car1_odom_publisher',
            name='car1_odom_publisher',
            output='screen',
        ),
        TimerAction(period=2.0, actions=[
            ExecuteProcess(
                cmd=[
                    'ros2', 'service', 'call', '/set_pose',
                    'robot_localization/srv/SetPose',
                    '{pose: {pose: {pose: {orientation: {w: 1.0}}}}}'
                ],
                output='screen',
            ),
        ]),

        TimerAction(period=5.0, actions=[
            Node(
                package='slam_toolbox',
                executable='async_slam_toolbox_node',
                name='slam_toolbox',
                parameters=[slam_params_file],
                output='screen',
            ),
            Node(
                package='nav2_lifecycle_manager',
                executable='lifecycle_manager',
                name='lifecycle_manager_slam',
                parameters=[{
                    'use_sim_time': False,
                    'autostart':    True,
                    'bond_timeout': 0.0,
                    'node_names':   ['slam_toolbox'],
                }],
                output='screen',
            ),
        ]),

        TimerAction(period=10.0, actions=[
            Node(
                package='nav2_planner',
                executable='planner_server',
                name='planner_server',
                parameters=[nav2_params],
                output='screen',
            ),

            Node(
                package='nav2_controller',
                executable='controller_server',
                name='controller_server',
                parameters=[nav2_params],
                remappings=[('cmd_vel', '/nav_cmd_vel')],
                output='screen',
            ),
            Node(
                package='nav2_smoother',
                executable='smoother_server',
                name='smoother_server',
                parameters=[nav2_params],
                output='screen',
            ),
            Node(
                package='nav2_behaviors',
                executable='behavior_server',
                name='behavior_server',
                parameters=[nav2_params],
                remappings=[('cmd_vel', '/behavior_cmd_vel')],
                output='screen',
            ),
            Node(
                package='twist_mux',
                executable='twist_mux',
                name='twist_mux',
                parameters=[{
                    'topics.recovery.topic':      '/recovery_cmd_vel', 
                    'topics.recovery.timeout':    0.3,                
                    'topics.recovery.priority':   20,  
                    'topics.navigation.topic':    '/nav_cmd_vel',
                    'topics.navigation.timeout':  0.5,
                    'topics.navigation.priority': 10,
                    'topics.behavior.topic':      '/behavior_cmd_vel',  
                    'topics.behavior.timeout':    0.5,
                    'topics.behavior.priority':   8,                    
                    'topics.joystick.topic':      '/joy_cmd_vel',
                    'topics.joystick.timeout':    0.5,
                    'topics.joystick.priority':   15,
                    'use_stamped': False,
                    }],
                remappings=[('cmd_vel_out', '/cmd_vel')],
                output='screen',
            ),
            Node(
                package='nav2_bt_navigator',
                executable='bt_navigator',
                name='bt_navigator',
                parameters=[nav2_params],
                output='screen',
            ),
            Node(
                package='nav2_waypoint_follower',
                executable='waypoint_follower',
                name='waypoint_follower',
                parameters=[nav2_params],
                output='screen',
            ),

            Node(
                package='nav2_lifecycle_manager',
                executable='lifecycle_manager',
                name='lifecycle_manager_navigation',
                parameters=[{
                    'use_sim_time': False,
                    'autostart':    True,
                    'bond_timeout': 0.0,
                    'node_names':   nav2_nodes,
                }],
                output='screen',
            ),
        ]),

        TimerAction(period=16.0, actions=[
            Node(
                package='rviz2',
                executable='rviz2',
                name='rviz2',
                arguments=rviz_args,
                parameters=[{'use_sim_time': False}],
                output='screen',
            ),
        ]),
    ])