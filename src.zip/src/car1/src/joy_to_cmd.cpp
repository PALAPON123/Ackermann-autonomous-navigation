// joy_to_cmd.cpp — v7

#include "rclcpp/rclcpp.hpp"
#include "sensor_msgs/msg/joy.hpp"
#include "geometry_msgs/msg/twist.hpp"
#include <chrono>
#include <cmath>

class JoyToCmd : public rclcpp::Node {
public:
  JoyToCmd() : Node("joy_to_cmd") {
    declare_parameter("max_speed", 0.3);
    declare_parameter("max_steer", 0.672);
    declare_parameter("deadzone",  0.05);
    max_speed_ = get_parameter("max_speed").as_double();
    max_steer_ = get_parameter("max_steer").as_double();
    deadzone_  = get_parameter("deadzone").as_double();

    pub_ = create_publisher<geometry_msgs::msg::Twist>("/cmd_vel", 10);

    sub_ = create_subscription<sensor_msgs::msg::Joy>(
      "/joy", 10,
      [this](const sensor_msgs::msg::Joy::SharedPtr msg) {
        last_joy_time_ = now();
        joy_lost_ = false;

        if ((int)msg->axes.size() < 6) return;

        float rt_raw = (float)msg->axes[5];
        float lt_raw = (float)msg->axes[2];
        // ถ้ายังไม่เคยกด (=0.0) ให้ถือว่าเป็น 1.0
        if (rt_raw == 0.0f && !rt_init_) rt_raw = 1.0f;
        else rt_init_ = true;
        if (lt_raw == 0.0f && !lt_init_) lt_raw = 1.0f;
        else lt_init_ = true;
        float rt = (1.0f - rt_raw) / 2.0f;
        float lt = (1.0f - lt_raw) / 2.0f;
        float steer = (float)msg->axes[0];

        if (std::abs(steer) < (float)deadzone_) steer = 0.0f;
        if (rt < (float)deadzone_) rt = 0.0f;
        if (lt < (float)deadzone_) lt = 0.0f;

        float steer_expo = 0.7f * steer * steer * steer + 0.3f * steer;
        float vx_raw     = rt - lt;
        float vx_expo    = 0.4f * vx_raw * vx_raw * vx_raw + 0.6f * vx_raw;

        last_cmd_.linear.x  = vx_expo   * (float)max_speed_;
        last_cmd_.angular.z = steer_expo * (float)max_steer_;
      });

    pub_timer_ = create_wall_timer(
  std::chrono::milliseconds(20),
  [this]() {
    double elapsed = (now() - last_joy_time_).seconds();
    if (elapsed > 1.0) {
      if (!joy_lost_) {
        joy_lost_ = true;
        RCLCPP_WARN(get_logger(), "joy lost — sending zero cmd");
      }
      geometry_msgs::msg::Twist zero;
      pub_->publish(zero);
      return;
    }

    bool is_zero = (std::abs(last_cmd_.linear.x)  < 1e-4) &&
                   (std::abs(last_cmd_.angular.z) < 1e-4);
    if (is_zero) {
      return;  // ไม่ publish เลย ปล่อยให้ topic เงียบ -> twist_mux timeout -> ปลด lock
    }

    pub_->publish(last_cmd_);
  });

    last_joy_time_ = now();
    RCLCPP_INFO(get_logger(),
      "joy_to_cmd v7  max_speed=%.2f  max_steer=%.3f  "
      "deadzone=%.2f  50Hz  watchdog=1000ms",
      max_speed_, max_steer_, deadzone_);
  }

private:
  rclcpp::Publisher<geometry_msgs::msg::Twist>::SharedPtr pub_;
  rclcpp::Subscription<sensor_msgs::msg::Joy>::SharedPtr  sub_;
  rclcpp::TimerBase::SharedPtr                            pub_timer_;
  geometry_msgs::msg::Twist                               last_cmd_;
  rclcpp::Time                                            last_joy_time_;
  bool   joy_lost_  = false;
  double max_speed_ = 0.3;
  double max_steer_ = 0.672;
  double deadzone_  = 0.05;
  bool rt_init_ = false;
  bool lt_init_ = false;
};

int main(int argc, char** argv) {
  rclcpp::init(argc, argv);
  rclcpp::spin(std::make_shared<JoyToCmd>());
  rclcpp::shutdown();
  return 0;
}